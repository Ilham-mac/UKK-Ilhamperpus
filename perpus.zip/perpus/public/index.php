<?php 
session_start();
include '../core/functions.php';
$url->run();