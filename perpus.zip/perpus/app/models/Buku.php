<?php 
class Buku extends BaseModel
{
  public $table_name  = "buku";
  public $table_id    = "BukuID";
}
