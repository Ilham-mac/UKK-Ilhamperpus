<?php 
class User extends BaseModel
{
  public $table_name  = "users";
  public $table_id    = "UserID";
}
