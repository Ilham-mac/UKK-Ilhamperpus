<?php 
class Kategoribuku extends BaseModel
{
  public $table_name  = "kategoribuku";
  public $table_id    = "KategoriID";
}
