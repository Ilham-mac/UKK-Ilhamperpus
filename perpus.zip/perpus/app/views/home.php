<?php include '../app/views/templates/header.php'; ?>
<div class="container-fluid">
<div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>Buku</p>
                <h3><?= hitung('buku'); ?></h3>

              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>
          <!-- ./col --><br>
          <div class="col-lg-3 col-5">
            <br>
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>Kategori Buku</p>
                <h3><?= hitung('kategoribuku'); ?></h3>
             
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>Buku Yang Dipinjam</p>
                <h3><?= hitung('peminjaman'); ?></h3>

              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <p>User</p>
                <h3><?= hitung('users'); ?></h3>

              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
        </div>
</div>
 Daftar Buku
 
<?php
// Menyediakan URL gambar
$image_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbFPpfm9zLtAG0FADZq2K4V-SND0C1MWK-SqQyJHwZuMhpqHrIezJdei9y1YM1wP9iQg4&usqp=CAU"; // Gambar placeholder (bisa diganti dengan URL gambar lain)
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gambar dalam Kotak</title>
    <style>
        /* Mengatur kotak */
        .image-box {
            width: 200px; /* Lebar kotak */
            height: 200px; /* Tinggi kotak */
            border: 2px solid #000; /* Garis border kotak */
            padding: 10px; /* Jarak antara gambar dan border */
            display: flex;
            justify-content: center; /* Menyusun gambar secara horizontal di tengah */
            align-items: center; /* Menyusun gambar secara vertikal di tengah */
            background-color: #f0f0f0; /* Warna latar belakang kotak */
        }
        .image-box img {
            width: 100%; /* Membuat gambar menyesuaikan dengan lebar kotak */
            height: auto; /* Menjaga rasio gambar */
        }
    </style>
</head>
<body>

    <div class="image-box">
        <!-- Menampilkan gambar menggunakan PHP -->
        <img src="<?php echo $image_url; ?>" alt="Gambar dalam Kotak">
    </div>

</body>
</html>


<?php include '../app/views/templates/footer.php'; ?>