<?php
if (isset($_POST['submit'])) {
    // Direktori tempat gambar akan disimpan
    $target_dir = "uploads/"; // Pastikan folder ini sudah ada dan memiliki izin yang benar
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;

    // Cek apakah file yang diunggah adalah gambar
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if (getimagesize($_FILES["fileToUpload"]["tmp_name"])) {
        echo "File adalah gambar.";
        $uploadOk = 1;
    } else {
        echo "File bukan gambar.";
        $uploadOk = 0;
    }

    // Cek apakah gambar sudah ada
    if (file_exists($target_file)) {
        echo "Maaf, gambar sudah ada.";
        $uploadOk = 0;
    }

    // Batasi ukuran file (misalnya 1MB)
    if ($_FILES["fileToUpload"]["size"] > 1000000) {
        echo "Maaf, ukuran gambar terlalu besar.";
        $uploadOk = 0;
    }

    // Cek apakah upload berhasil
    if ($uploadOk == 0) {
        echo "Maaf, gambar Anda tidak dapat diunggah.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "Gambar " . basename($_FILES["fileToUpload"]["name"]) . " telah diunggah.";
            // Menampilkan gambar setelah diunggah
            echo "<br><img src='$target_file' alt='Uploaded Image' width='300'>";
        } else {
            echo "Maaf, terjadi kesalahan saat mengunggah gambar.";
        }
    }
}
?>
